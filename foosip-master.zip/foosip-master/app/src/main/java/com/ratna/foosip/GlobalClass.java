//package com.ratna.foosip;
//
//import android.app.Application;
//
//import java.util.ArrayList;
//import java.util.HashMap;
//
///**
// * Created by ratna on 10/10/2016.
// */
//public class GlobalClass extends Application {
//
//
//}
