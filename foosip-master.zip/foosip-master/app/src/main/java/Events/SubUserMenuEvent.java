package Events;

/**
 * Created by ratna on 11/25/2016.
 */

public class SubUserMenuEvent {
}
