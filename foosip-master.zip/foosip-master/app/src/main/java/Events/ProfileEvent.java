package Events;

import java.util.List;

import Model.HistoryJson;
import Model.ProfileJson;

/**
 * Created by ratna on 1/5/2017.
 */
public class ProfileEvent {

    private String profile;


}
