package Model;

import android.widget.ImageView;

import com.ratna.foosip.Feedback;

/**
 * Created by ratna on 11/25/2016.
 */

public class FeedBack {

    ImageView imageView;

    public FeedBack()
    {

    }
}
