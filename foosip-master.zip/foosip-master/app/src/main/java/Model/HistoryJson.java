package Model;

/**
 * Created by ratna on 1/4/2017.
 */
public class HistoryJson {

    private String rid;
    private String txt_address;
    private String res_area;
    private String name;
    private String temp_order_id;
    private String date1;
    private String rname;
    private String rlogo;


    public String getRid() {
        return rid;
    }
    public void setRid(String rid) {
        this.rid = rid;
    }
    public String getTxt_address() {
        return txt_address;
    }
    public void setTxt_address(String txt_address) {
        this.txt_address = txt_address;
    }


    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }

    public String getTemp_order_id() {
        return temp_order_id;
    }
    public void setTemp_order_id(String temp_order_id) {
        this.temp_order_id = temp_order_id;
    }
    public String getDate1() {
        return date1;
    }
    public void setDate1(String date1) {
        this.date1 = date1;
    }
    public String getRname() {
        return rname;
    }
    public void setRname(String rname) {
        this.rname = rname;
    }

    public String getRlogot() {
        return rlogo;
    }
    public void setRlogo(String rlogo) {
        this.rlogo = rlogo;
    }
}

