package NotificationNoServer;

/**
 * Created by prabhat on 14/2/18.
 */

public interface FirebaseNotiCallBack {
    void success(String s);

    void fail(String s);
}
